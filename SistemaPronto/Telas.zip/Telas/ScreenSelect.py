import tkinter as tk
from Telas import ScreenAdminstracao, ScreenClientes, ScreenFuncionarios, ScreenMaquinarios

class Aplication:
  def __init__(self, master = None) -> None:
    self.master = master
    self.SelectScreen = tk.Frame(master)
    self.SelectScreen.place(relx=0.5, rely=0.5, anchor="center")

    self.Cliente = tk.Button(self.SelectScreen, text="Cliente", command=self.cliente, font="Arial 40", width=16)
    self.Cliente.grid(row=0, column=0, padx=10, pady=10)
    
    self.Funcionario = tk.Button(self.SelectScreen, text="Funcionário", command=self.funcionario, font="Arial 40", width=16)
    self.Funcionario.grid(row=0, column=1, padx=10, pady=10)
    
    self.Maquinario = tk.Button(self.SelectScreen, text="Maquinario", command=self.maquinario, font="Arial 40", width=16)
    self.Maquinario.grid(row=1, column=0, padx=10, pady=10)
    
    self.Administracao = tk.Button(self.SelectScreen, text="Administração", command=self.administracao, font="Arial 40", width=16)
    self.Administracao.grid(row=1, column=1, padx=10, pady=10)
  
  def cliente(self) -> None:
    self.master.destroy()
    ScreenClientes.main()

  def funcionario(self) -> None:
    self.master.destroy()
    ScreenFuncionarios.main()

  def maquinario(self) -> None:
    self.master.destroy()
    ScreenMaquinarios.main()

  def administracao(self) -> None:
    self.master.destroy()
    ScreenAdminstracao.main()

def main() -> None:
  root = tk.Tk()
  root.state('zoomed')
  root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
  root.title("Tela de Seleção")
  Aplication(root)
  root.mainloop()
