# Consultar
class Consultar:
  def __init__(self) -> None:
    pass

  @staticmethod
  def consultar(arq:str) -> list[list]:
    listaCadastros = []
    
    with open(f"./Telas/Cadastros/{arq}.txt", "r") as file:
      for line in file:
        cadastroCliente = line.strip().split("|")
        if cadastroCliente[0] == "O":
          listaCadastros.append(cadastroCliente)
    
    return listaCadastros

# Inserir
class Inserir:
  def __init__(self) -> None:
    pass

  @staticmethod
  def inserir(arq:str, args) -> None: # nome = None, cpf = None, dataNasc = None, sexo = None, plano = None, email = None
    
    with open(f"./Telas/Cadastros/{arq}.txt", "r") as file:
      fileLines = file.readlines()
      if len(fileLines) > 1:
        lastID = fileLines[len(fileLines) - 1].strip().split("|")[1]
      else:
        lastID = 0

    with open(f"./Telas/Cadastros/{arq}.txt", "a") as file:
      s = f"O|{int(lastID)+1}"

      for iten in args:
        s += f"|{iten}"
      s += "\n"

      file.write(s)

# Alterar
class Alterar:
  def __init__(self) -> None:
    pass

  @staticmethod
  def alterar(arq:str, id: str, args:tuple) -> None:
    
    with open(f"./Telas/Cadastros/{arq}.txt", "r") as file:
      fileLines = file.readlines()
      for numLine, line in enumerate(fileLines):
        cadastro = line.strip().split("|")

        count = 2

        if cadastro[1] == id:
          for iten in args:
            if iten:
              cadastro[count] = iten
            count+=1
          
          newLine = "|".join(cadastro)

          fileLines[numLine] = newLine + "\n"

          with open(f"./Telas/Cadastros/{arq}.txt", "w") as file2:
            file2.writelines(fileLines)
          break

# Suspender
class Suspender:
  def __init__(self) -> None:
    pass

  @staticmethod
  def suspender(arq:str, id: str) -> None:
    with open(f"./Telas/Cadastros/{arq}.txt", "r") as file:
      fileLines = file.readlines()
      for numLine, line in enumerate(fileLines):
        cadastro = line.strip().split("|")
          
        if cadastro[1] == id:
          cadastro[0] = "X"
          newLine = "|".join(cadastro)

          fileLines[numLine] = newLine + "\n"

          with open(f"./Telas/Cadastros/{arq}.txt", "w") as file2:
            file2.writelines(fileLines)
          break