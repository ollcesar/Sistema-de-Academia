import tkinter as tk
from Telas.Cadastros.Cadastros import Suspender

class Aplication:
    def __init__(self, master = None, code:str = '-1', line=None, arq=None) -> None:
        self.master = master
        self.code = code
        self.line = line
        self.arq = arq

        self.Mensage = tk.Label(self.master, text="Deseja mesmo excluir esté cadastro?", fg='red',font="bold")
        self.Mensage.pack()

        self.Line = tk.Frame(self.master)
        self.Line.pack()

        self.Cancel = tk.Button(self.Line, text="Cancelar", command=self.master.destroy)
        self.Cancel.pack(side='left', padx=10)

        self.Confirm = tk.Button(self.Line, text="Confirmar", fg='red', command=self.confirm)
        self.Confirm.pack(side='right')
    
    def confirm(self) -> None:
        Suspender.suspender(self.arq, self.code)
        self.line.destroy()
        self.master.destroy()

def main(code:str, line, arq) -> None:
    root = tk.Tk()
    root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
    root.title("Excluir Cadastro")
    Aplication(root, code, line, arq)
    root.mainloop()
