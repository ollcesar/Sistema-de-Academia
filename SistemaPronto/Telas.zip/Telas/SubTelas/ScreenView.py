import tkinter as tk
from Telas.Cadastros.Cadastros import Consultar

class Aplication:
    def __init__(self, master = None, code:str = '-1', arq=None) -> None:
        self.master = master
        self.code = code
        self.arq = arq

        personas = Consultar.consultar(self.arq)
        indv = []

        for per in personas:
            if per[1] == self.code:
                indv = per
                break

        if self.arq == "Clientes":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Plano','Email']
        elif self.arq == "Funcionarios":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Função','Salário','Email']
        elif self.arq == "Maquinarios":
            order = ['Nome','Código','Quantidade','Origem','Contato do Fornecedor']

        self.Persona = tk.Frame(self.master)
        self.Persona.pack()

        for i, iten in enumerate(indv[2:]):
            self.Nome = tk.Label(self.Persona, text=f"{order[i]}: {iten}", anchor='w')
            self.Nome.pack(fill='x')

        self.Sair = tk.Button(self.Persona, text="Sair", command=self.master.destroy, padx=10)
        self.Sair.pack(pady=5)

def main(code:str, arq) -> None:
    root = tk.Tk()
    root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
    root.title("Visualizar Cadastro")
    Aplication(root, code, arq)
    root.mainloop()
