import tkinter as tk
from Tools.EntryWithPlaceholder import EntryWithPlaceholder
from Telas.Login.LoginConfirm import LoginConfirm

class Aplication:
    def __init__(self, master = None, who:str = None) -> None:
        self.master = master
        self.who = who

        self.AlterPassScreen = tk.Frame(self.master)
        self.AlterPassScreen.pack()

        self.ADMuser = EntryWithPlaceholder(self.AlterPassScreen, placeholder="Usuário do Administrador", showing="*")
        self.ADMuser.pack()
        self.ADMpass = EntryWithPlaceholder(self.AlterPassScreen, placeholder="Senha do Administrador", showing="*")
        self.ADMpass.pack()

        self.newUser = EntryWithPlaceholder(self.AlterPassScreen, placeholder="Novo Usuário", showing="*")
        self.newUser.pack()
        self.newPass = EntryWithPlaceholder(self.AlterPassScreen, placeholder="Nova Senha", showing="*")
        self.newPass.pack()

        self.Line = tk.Frame(self.AlterPassScreen)
        self.Line.pack()

        self.Cancel = tk.Button(self.Line, text="Cancelar", command=self.master.destroy)
        self.Cancel.pack(side='left', padx=5)

        self.Alter = tk.Button(self.Line, text="Alterar", fg="dark orange", command=self.alter)
        self.Alter.pack(side='right', padx=5)

        self.Mensagelabel = tk.Label(self.AlterPassScreen, text="", fg="red")
        self.Mensagelabel.pack(side="bottom")
        self.MensagelabelID = ""

    def alter(self) -> None:
        ADMuser = self.ADMuser.get().strip()
        ADMpass = self.ADMpass.get().strip()

        if LoginConfirm.confirm(user=ADMuser, passworld=ADMpass):
            newuser = self.newUser.get().strip()
            newpass = self.newPass.get().strip()

            if self.who == "Func":
                LoginConfirm.alterar(newUser=newuser, newPassworld=newpass)
            elif self.who == "ADM":
                LoginConfirm.alterarADM(newUser=newuser, newPassworld=newpass)

            self.master.destroy()
        else:
            self.Alter.focus_set()
            self.ADMuser.delete(0, tk.END)
            self.ADMuser.foc_out()
            self.ADMpass.delete(0, tk.END)
            self.ADMpass.foc_out()
            self.newUser.delete(0, tk.END)
            self.newUser.foc_out()
            self.newPass.delete(0, tk.END)
            self.newPass.foc_out()
            self.Mensagelabel["text"] = "Usuário ou senha incorretos"
            if self.MensagelabelID:
                self.Mensagelabel.after_cancel(self.MensagelabelID)
            self.MensagelabelID = self.Mensagelabel.after(2000, self.clear)

    def clear(self) -> None:
        self.Mensagelabel["text"] = ""

def main(who:str=None) -> None:
    root = tk.Tk()
    root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
    root.title("Alterar Senhas")
    Aplication(root, who)
    root.mainloop()