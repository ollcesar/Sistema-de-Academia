import tkinter as tk
from Telas.Cadastros.Cadastros import Consultar, Alterar

class Aplication:
    def __init__(self, master = None, code:str = '-1', arq=None, namel=None) -> None:
        self.master = master
        self.code = code
        self.arq = arq
        self.namel = namel

        personas = Consultar.consultar(self.arq)
        indv = []

        for per in personas:
            if per[1] == self.code:
                indv = per
                break

        if self.arq == "Clientes":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Plano','Email']
        elif self.arq == "Funcionarios":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Função','Salário','Email']
        elif self.arq == "Maquinarios":
            order = ['Nome','Código','Quantidade','Origem','Contato do Fornecedor']

        self.Persona = tk.Frame(self.master)
        self.Persona.pack()

        self.entrys = []

        for i, iten in enumerate(indv[2:]):
            self.LineC = tk.Frame(self.Persona)
            self.LineC.pack(fill='x')
            self.L = tk.Label(self.LineC, text=f"{order[i]}:", anchor='w')
            self.L.pack(side='left')
            self.E= tk.Entry(self.LineC)
            self.entrys.append(self.E)
            self.entrys[i].insert(0, iten)
            self.entrys[i].pack(side='right',fill='x', expand=1)

        self.Line = tk.Frame(self.Persona)
        self.Line.pack(pady=5)
        
        self.Cancel = tk.Button(self.Line, text="Cancelar", command=self.master.destroy, padx=10)
        self.Cancel.pack(side='left', padx=10)

        self.Confirm = tk.Button(self.Line, text="Alterar", fg='dark orange', command=self.confirm)
        self.Confirm.pack(side='right')
    
    def confirm(self) -> None:
        elements = []
        for iten in self.entrys:
            loc = iten.get().strip()
            while loc != loc.replace("  ", " "):
                loc = loc.replace("  ", " ")
            elements.append(loc)

        self.namel['text'] = elements[0]

        Alterar.alterar(self.arq, self.code, tuple(elements))
        self.master.destroy()

def main(code:str, arq, namel) -> None:
    root = tk.Tk()
    root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
    root.title("Alterar Cadastro")
    Aplication(root, code, arq, namel)
    root.mainloop()
