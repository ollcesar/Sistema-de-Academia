import tkinter as tk
from Telas.Cadastros.Cadastros import Inserir
from Telas import ScreenClientes, ScreenFuncionarios, ScreenMaquinarios

class Aplication:
    def __init__(self, master = None, arq=None) -> None:
        self.master = master
        self.arq = arq

        if self.arq == "Clientes":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Plano','Email']
        elif self.arq == "Funcionarios":
            order = ['Nome','CPF','Data de Nascimento','Sexo','Função','Salário','Email']
        elif self.arq == "Maquinarios":
            order = ['Nome','Código','Quantidade','Origem','Contato do Fornecedor']

        self.Persona = tk.Frame(self.master)
        self.Persona.pack()

        self.entrys = []

        for i, iten in enumerate(order):
            self.LineC = tk.Frame(self.Persona)
            self.LineC.pack(fill='x')
            self.L = tk.Label(self.LineC, text=f"{iten}:", anchor='w')
            self.L.pack(side='left')
            self.E= tk.Entry(self.LineC)
            self.entrys.append(self.E)
            self.entrys[i].pack(side='right',fill='x', expand=1)

        self.Line = tk.Frame(self.Persona)
        self.Line.pack(pady=5)
        
        self.Cancel = tk.Button(self.Line, text="Cancelar", command=self.master.destroy, padx=10)
        self.Cancel.pack(side='left', padx=10)

        self.Confirm = tk.Button(self.Line, text="Inserir", fg='dark orange', command=self.confirm)
        self.Confirm.pack(side='right')
    
    def confirm(self) -> None:
        elements = []
        for iten in self.entrys:
            loc = iten.get().strip()
            while loc != loc.replace("  ", " "):
                loc = loc.replace("  ", " ")
            elements.append(loc)

        Inserir.inserir(self.arq, tuple(elements))
        if self.arq == "Clientes":
            ScreenClientes.refresh()
        elif self.arq == "Funcionarios":
            ScreenFuncionarios.refresh()
        elif self.arq == "Maquinarios":
            ScreenMaquinarios.refresh()
        self.master.destroy()
        
def main(arq:str) -> None:
    root = tk.Tk()
    root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
    root.title("Adicionar Cadastro")
    Aplication(root, arq)
    root.mainloop()
