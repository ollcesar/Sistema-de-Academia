import tkinter as tk
from Telas import ScreenSelect
from Telas.SubTelas import ScreenAlterPass

class Aplication:
  def __init__(self, master = None) -> None:
    self.master = master
    self.AdministracaoScreen = tk.Frame(self.master)
    self.AdministracaoScreen.place(relx=0.5, rely=0.5, anchor="center")

    self.VoltarBotao = tk.Button(self.master, text="Voltar", command=self.voltar, font="Arial 15")
    self.VoltarBotao.place(x=0, y=0)

    self.SenhaFunc = tk.Button(self.AdministracaoScreen, text="Alterar Senha Funcionário", font="Arial 30", command=lambda: self.senha("Func"))
    self.SenhaFunc.pack(pady=10)

    self.SenhaADM = tk.Button(self.AdministracaoScreen, text="Alterar Senha Administração", font="Arial 30", command=lambda: self.senha("ADM"))
    self.SenhaADM.pack(pady=10)
  
  def senha(self, who:str=None) -> None:
    ScreenAlterPass.main(who)
    pass

  def voltar(self) -> None:
    self.master.destroy()
    ScreenSelect.main()

def main() -> None:
  root = tk.Tk()
  root.state('zoomed')
  root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
  root.title("Administração")
  Aplication(root)
  root.mainloop()