import tkinter as tk
from Tools.EntryWithPlaceholder import EntryWithPlaceholder
from Telas import ScreenSelect
from Telas.SubTelas import ScreenAdd
from Tools.MyList import MyList

apli = None

class Aplication:
  def __init__(self, master = None) -> None:
    self.master = master
    self.MaquinarioScreen = tk.Frame(master)
    self.MaquinarioScreen.pack()

    self.TopScreen = tk.Frame(self.MaquinarioScreen)
    self.TopScreen.pack()

    self.VoltarBotao = tk.Button(self.master, text="Voltar", command=self.voltar)
    self.VoltarBotao.place(x=0, y=0)

    self.TituloLabel = tk.Label(self.TopScreen, text="Maquinarios", font="15")
    self.TituloLabel.pack()

    self.MiddleScreen = tk.Frame(self.MaquinarioScreen, width=750)
    self.MiddleScreen.pack()

    self.BarraPesquisa = EntryWithPlaceholder(self.MiddleScreen, "Pesquisar", "gray", fontConf="Arial 15")
    self.BarraPesquisa.configure(width=50)
    self.BarraPesquisa.pack(side=tk.LEFT)

    self.BotaoPesquisa = tk.Button(self.MiddleScreen, text="Pesquisar", command=self.pesquisar)
    self.BotaoPesquisa.pack(side=tk.LEFT)

    self.BotaoFiltro = tk.Button(self.MiddleScreen, text = "Filtro", command=self.filtro)
    # self.BotaoFiltro.pack(side=tk.LEFT)

    self.BotaoAdicionar = tk.Button(self.MiddleScreen, text = "Adicionar", command=self.adicionar)
    self.BotaoAdicionar.pack(side=tk.LEFT)

    # tamanhoEntry = master.winfo_screenwidth() - self.BotaoAdicionar.winfo_screenwidth() - self.BotaoFiltro.winfo_screenwidth() - self.BotaoPesquisa.winfo_screenwidth()

    # self.BarraPesquisa.configure(width=tamanhoEntry)

    self.ListScreen = tk.Frame(self.MaquinarioScreen)
    self.ListScreen.configure(width=1000)
    self.ListScreen.pack(pady=10)

    self.mylist = MyList(master=self.ListScreen, arq="Maquinarios")
  
  def pesquisar(self) -> None:
    nome = self.BarraPesquisa.get().strip()
    while nome != nome.replace("  ", " "):
      nome = nome.replace("  ", " ")
    
    self.mylist.destroy()
    self.mylist = MyList(master=self.ListScreen, nome=nome, arq="Maquinarios")

  def filtro(self) -> None:
    pass

  def adicionar(self) -> None:
    ScreenAdd.main("Maquinarios")

  def voltar(self) -> None:
    self.master.destroy()
    ScreenSelect.main()

def main() -> None:
  root = tk.Tk()
  root.state('zoomed')
  root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
  root.title("Maquinarios")
  global apli
  apli = Aplication(root)
  root.mainloop()

def refresh() -> None:
  global apli
  apli.pesquisar()