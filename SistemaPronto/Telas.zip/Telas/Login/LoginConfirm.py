class LoginConfirm:

  def __init__(self) -> None:
    pass

  @staticmethod
  def confirm(user: str, passworld: str) -> bool:
    with open("./Telas/login/LoginUsersPass.txt", "r") as file:
      for line in file:
        if line.strip() == f"{user}:{passworld}":
          return True
    return False

  @staticmethod
  def alterar(newUser: str, newPassworld: str) -> None:
    with open("./Telas/login/LoginUsersPass.txt", "r") as file:
      fileLines = file.readlines()
      fileLines[0] = f"{newUser}:{newPassworld}\n"
      with open("./Telas/login/LoginUsersPass.txt", "w") as file2:
        file2.writelines(fileLines)

  @staticmethod
  def alterarADM(newUser: str, newPassworld: str) -> None:
    with open("./Telas/login/LoginUsersPass.txt", "r") as file:
      fileLines = file.readlines()
      fileLines[1] = f"{newUser}:{newPassworld}\n"
      with open("./Telas/login/LoginUsersPass.txt", "w") as file2:
        file2.writelines(fileLines)
