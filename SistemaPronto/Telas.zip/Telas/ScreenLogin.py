import tkinter as tk
from Telas.Login.LoginConfirm import LoginConfirm
from Telas import ScreenSelect
from Tools.EntryWithPlaceholder import EntryWithPlaceholder

class Aplication:
  def __init__(self, master = None) -> None:
    self.master = master
    self.LoginScreen = tk.Frame(self.master)
    self.LoginScreen.place(relx=0.5, rely=0.5, relwidth=0.5, anchor="center")

    self.Title = tk.Label(self.LoginScreen, text="Sistema de Academia", font="Arial 50", pady=40)
    self.Title.pack()

    self.UserEntry = EntryWithPlaceholder(self.LoginScreen, "Usuario", "gray", showing="*", fontConf="Arial 25")
    self.PassworldEntry = EntryWithPlaceholder(self.LoginScreen, "Senha", "gray", showing="*", fontConf="Arial 25")
    self.UserEntry.pack()
    self.PassworldEntry.pack()

    self.ButtonConfirm = tk.Button(self.LoginScreen, text="Confirmar", command=self.confirm, font="Arial 25")
    self.ButtonConfirm.pack(pady=20)

    self.Mensagelabel = tk.Label(self.LoginScreen, text="", fg="red")
    self.Mensagelabel.pack()
    self.MensagelabelID = ""

  def confirm(self) -> None:
    user = self.UserEntry.get().strip()
    passworld = self.PassworldEntry.get().strip()

    if LoginConfirm.confirm(user, passworld):
      self.master.destroy()
      ScreenSelect.main()
    else:
      self.ButtonConfirm.focus_set()
      self.UserEntry.delete(0, tk.END)
      self.UserEntry.foc_out()
      self.PassworldEntry.delete(0, tk.END)
      self.PassworldEntry.foc_out()
      self.Mensagelabel["text"] = "Usuário ou senha incorretos"
      if self.MensagelabelID:
        self.Mensagelabel.after_cancel(self.MensagelabelID)
      self.MensagelabelID = self.Mensagelabel.after(2000, self.clear)

  def clear(self) -> None:
    self.Mensagelabel["text"] = ""

def main() -> None:
  root = tk.Tk()
  root.state('zoomed')
  root.iconbitmap("./Tools/among_us_player_light_blue_icon_156934.ico")
  root.title("Login")
  Aplication(root)
  root.mainloop()
  
