import tkinter as tk

class EntryWithPlaceholder(tk.Entry):
  def __init__(self, master=None, placeholder="PLACEHOLDER", color='grey', showing="", fontConf=""):
    super().__init__(master)

    if fontConf:
      self.configure(font=fontConf)
    self.showing = showing
    self.placeholder = placeholder
    self.placeholder_color = color
    self.default_fg_color = self['fg']

    self.bind("<FocusIn>", self.foc_in)
    self.bind("<FocusOut>", self.foc_out)

    self.put_placeholder()

  def put_placeholder(self):
    self.delete(0, tk.END)
    self.insert(0, self.placeholder)
    self['fg'] = self.placeholder_color

  def foc_in(self, *args):
    if self['fg'] == self.placeholder_color:
      self.delete('0', 'end')
      self['fg'] = self.default_fg_color
      self['show'] = self.showing

  def foc_out(self, *args):
    if not self.get():
      self['show'] = ""
      self.put_placeholder()

  def get(self) -> str:
    if self['fg'] == self.placeholder_color:
      return ""
    return super().get()