import tkinter as tk
from Telas.Cadastros.Cadastros import Consultar
from Telas.SubTelas import ScreenDel, ScreenView, ScreenEdit

class MyList(tk.Frame):
  def __init__(self, master, nome:str=None, arq:str=None):
    super().__init__(master)
    self.pack()
    self.configure(width=1000)
    self.nome = nome
    self.arq = arq

    # main
    main_frame = tk.Frame(self)
    main_frame.pack(fill=tk.BOTH, expand=1)

    # canvas
    self.my_canvas = tk.Canvas(main_frame, width=800, height=500)
    self.my_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

    # scrollbar
    my_scrollbar = tk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.my_canvas.yview)
    my_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # configure the canvas
    self.my_canvas.configure(yscrollcommand=my_scrollbar.set)
    self.my_canvas.bind(
        '<Configure>', lambda e: self.my_canvas.configure(scrollregion=self.my_canvas.bbox("all"))
    )

    self.second_frame = tk.Frame(self.my_canvas, height = 100)
    self.second_frame.configure(width=1000)

    self.my_canvas.create_window((0, 0), window=self.second_frame, anchor="nw")
    self.updateList(self.nome)

  def updateList(self, nome:str=None):

    cadastros = Consultar.consultar(self.arq)

    btns = {
      "btnView": [],
      "btnEdit": [],
      "btnDel": []
    }

    count = 0

    cl = 'gray69'

    for i, cadastro in enumerate(cadastros):
      if nome:
        if not nome in cadastro[2]:
          continue
      
      line = tk.Frame(self.second_frame, width=1000, bg=f'{cl}')
      line.pack(fill='both')

      nameLabel = tk.Label(line, text=cadastro[2], anchor="w", width=120, bg=f'{cl}', padx=2)

      if cl=='gray69':
        cl = 'light gray'
      else:
        cl = 'gray69'

      btnView = tk.Button(line,
                        text="Ver",
                        compound="left",
                        fg="blue",
                        font=("bold", 10),
                        height=1,
                        command=lambda c=cadastro[1]: ScreenView.main(c, self.arq)
                        )
      
      btnEdit = tk.Button(line,
                        text="Editar",
                        compound="left",
                        fg="blue",
                        font=("bold", 10),
                        height=1,
                        command=lambda c=cadastro[1], namel=nameLabel: ScreenEdit.main(c, self.arq, namel)
                        )
      
      btnDel = tk.Button(line,
                        text="Excluir",
                        compound="left",
                        fg="blue",
                        font=("bold", 10),
                        height=1,
                        command=lambda c=cadastro[1], line1=line: ScreenDel.main(c, line1, self.arq)
                        )
      
      btns["btnDel"].append(btnDel)
      btns["btnEdit"].append(btnEdit)
      btns["btnView"].append(btnView)

      nameLabel.pack(side='right', fill='x', expand=1, padx=2)
      btns["btnView"][count].pack(side='right')
      btns["btnEdit"][count].pack(side='right', padx=2, pady=2)
      btns["btnDel"][count].pack(side='right', padx=2)

      count += 1